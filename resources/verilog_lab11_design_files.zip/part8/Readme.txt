The files part8.qsf and part8.cdf are suitable for the DE1-SoC board. If you 
are using a different board, then these files should be changed as needed.
